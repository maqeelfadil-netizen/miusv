# Elytra Swap - Fabric 1.21.11

Client-side Fabric mod with one customizable keybind.

## What it does
- Default key: R
- Press the key while wearing an Elytra to move it back into the inventory.
- Press it while not wearing an Elytra to equip the first Elytra found in the inventory.
- Change the key under Minecraft > Options > Controls > Key Binds.

## Build
Use Java 21 and run:

    ./gradlew build

The resulting JAR will be in:

    build/libs/

Minecraft 1.21.11 is the final obfuscated 1.21 release, so this project uses Fabric Loom's remap plugin as documented by Fabric.
