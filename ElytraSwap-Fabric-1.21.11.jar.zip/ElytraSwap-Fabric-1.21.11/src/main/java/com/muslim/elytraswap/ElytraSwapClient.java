package com.muslim.elytraswap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public class ElytraSwapClient implements ClientModInitializer {
    private static KeyBinding swapKey;

    @Override
    public void onInitializeClient() {
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elytraswap.swap",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.elytraswap"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(ElytraSwapClient::onClientTick);
    }

    private static void onClientTick(MinecraftClient client) {
        while (swapKey.wasPressed()) {
            if (client.player == null || client.interactionManager == null) {
                continue;
            }

            ItemStack chest = client.player.getEquippedStack(EquipmentSlot.CHEST);

            if (chest.isOf(Items.ELYTRA)) {
                moveChestToInventory(client);
            } else {
                equipElytraFromInventory(client);
            }
        }
    }

    private static void moveChestToInventory(MinecraftClient client) {
        ItemStack chest = client.player.getEquippedStack(EquipmentSlot.CHEST);
        if (chest.isEmpty()) return;

        int slot = findEmptyInventorySlot(client);
        if (slot < 0) return;

        client.player.getInventory().setStack(slot, chest.copy());
        client.player.equipStack(EquipmentSlot.CHEST, ItemStack.EMPTY);
    }

    private static void equipElytraFromInventory(MinecraftClient client) {
        int slot = findElytra(client);
        if (slot < 0) return;

        ItemStack elytra = client.player.getInventory().getStack(slot).copy();
        client.player.getInventory().setStack(slot, ItemStack.EMPTY);
        client.player.equipStack(EquipmentSlot.CHEST, elytra);
    }

    private static int findElytra(MinecraftClient client) {
        for (int i = 0; i < client.player.getInventory().size(); i++) {
            if (client.player.getInventory().getStack(i).isOf(Items.ELYTRA)) {
                return i;
            }
        }
        return -1;
    }

    private static int findEmptyInventorySlot(MinecraftClient client) {
        for (int i = 0; i < client.player.getInventory().size(); i++) {
            if (client.player.getInventory().getStack(i).isEmpty()) {
                return i;
            }
        }
        return -1;
    }
}
